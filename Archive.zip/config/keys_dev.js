module.exports = {
  mongoURI:
    // "mongodb+srv://kenaridb:kenariku123@kenaridb-6pm3p.mongodb.net/test?retryWrites=true&w=majority",
    // "mongodb+srv://ptpnxdjoembangbaru:djoembangbaruptpnx@ptpnx-djoembang-d15dj.mongodb.net/test?retryWrites=true&w=majority",
    // "mongodb+srv://panjigemilang:xtremesuper98@devconnector-vasnt.mongodb.net/test?retryWrites=true&w=majority",
    "mongodb+srv://ternakadmin:ternakan@ternakdb-gx3sw.mongodb.net/test?retryWrites=true&w=majority",
  secretOrKey: "secret"
};
